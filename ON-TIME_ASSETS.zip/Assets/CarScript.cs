using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CarScript : MonoBehaviour
{
    public int startX = 0;
    public int startY = 0;

    public int X = 0;
    public int Y = 0;

    public int dirX = 1;
    public int dirY = 0;

    public GridScript grid;

    public Quaternion targetRotation;
    public Vector3 oldPosition;
    public Vector3 truePosition;
    public float stepProgress = 1f;

    public GameManager gm;

    public AudioSource rotateSound;

    public List<GameObject> collisionObjects;
    public int lastTile;
    public int collTile;

    private void Awake()
    {
        X = startX;
        Y = startY;
        //grid = transform.root.Find("Grid").GetComponent<GridScript>();
        truePosition = grid.getTileCoordinate(startX, startY);
        oldPosition = truePosition;
        FaceDir();
        transform.rotation = targetRotation;
        transform.position = truePosition;
    }

    public void FaceDir()
    {
        if (dirX == 1) { targetRotation = Quaternion.Euler(0, 0, 270); }
        else if (dirX == -1) { targetRotation = Quaternion.Euler(0, 0, 90); }
        else if (dirY == -1) { targetRotation = Quaternion.Euler(0, 0, 0); }
        else { targetRotation = Quaternion.Euler(0, 0, 180); }
    }

    public void TurnRight()
    {
        if (dirX == -1) { dirX = 0; dirY = -1; }
        else if (dirX == 1) { dirX = 0; dirY = 1; }
        else if (dirY == -1) { dirX = 1; dirY = 0; }
        else { dirX = -1; dirY = 0; }
    }

    public void TurnLeft()
    {
        if (dirX == 1) { dirX = 0; dirY = -1; }
        else if (dirX == -1) { dirX = 0; dirY = 1; }
        else if (dirY == 1) { dirX = 1; dirY = 0; }
        else { dirX = -1; dirY = 0; }
    }

    public void Step()
    {
        oldPosition = transform.position;

        //IF ON ROTATE ENTITY, ROTATE 
        //ELSE IF ON ROAD AND BLOCK FORWARD, 
        int curTile = grid.getTileIndex(X, Y);
        lastTile = curTile;
        string n = grid.placeableItem(curTile);
        if (grid.containsPlaceableItemCar(curTile) || grid.grid[curTile].tileType >= 2)
        {
            if (n == "PoliceRightTurn" || grid.grid[curTile].tileType == 2)
            {
                TurnRight();
                //rotateSound.pitch = Random.Range(0.8f, 1.2f);
                //rotateSound.Play();
                if (n == "PoliceRightTurn") grid.playWhistle(curTile);
            }
            else if (n == "PoliceLeftTurn" || grid.grid[curTile].tileType == 3)
            {
                TurnLeft();
                //rotateSound.pitch = Random.Range(0.8f, 1.2f);
                //rotateSound.Play();
                if (n == "PoliceLeftTurn") grid.playWhistle(curTile);
            }
        }
        else if (grid.getTileAt(X + dirX, Y + dirY) == 0)
        {
            TurnLeft();
            if (!(grid.getTileAt(X + dirX, Y + dirY) != 0 && grid.getTileAt(X - dirX, Y - dirY) == 0))
            {
                TurnRight();
                TurnRight();
            }
        }

        //ELSE GO FORTH

        if (grid.getTileAt(X + dirX, Y + dirY) != 0)
        {
            X += dirX;
            Y += dirY;
        }

        collTile = grid.getTileIndex(X, Y);
        collisionObjects = grid.vehicle(collTile);

        if (grid.grid[lastTile].entities.Contains(gameObject)) grid.grid[lastTile].entities.Remove(gameObject);
        grid.grid[collTile].entities.Add(gameObject);

        FaceDir();
        truePosition = grid.getTileCoordinate(X, Y);
    }

    public int CollisionStep()
    {
        int destroy = 0;
        bool endGame = false;
        Debug.Log("test" + collisionObjects.Count.ToString());
        foreach (GameObject o in collisionObjects)
        {
            if (o != gameObject && (grid.vehicle(collTile).Contains(o) || grid.vehicle(lastTile).Contains(o)))
            {
                if (o.GetComponent<CarScript>()!=null)
                {
                    destroy++;
                    o.GetComponent<CarScript>().commitDie();
                } else if (o.GetComponent<ScooterScript>()!=null)
                {
                    endGame = true;
                }
            }
        }
        if (endGame)
        {
            gm.EndGame(true);
        }
        if (destroy > 0)
        {
            gm.cars.Remove(this);
            grid.grid[collTile].entities.Remove(gameObject);
            GameObject fx = Instantiate(transform.Find("destroyFX").gameObject);
            fx.SetActive(true);
            fx.GetComponent<AudioSource>().Play();
            fx.transform.Find("Particle System").GetComponent<ParticleSystem>().Emit(100);
            fx.transform.position = transform.position + new Vector3(dirX*grid.tileSize, dirY * grid.tileSize,0f);
            Destroy(gameObject);
            return destroy;
        } else
        {
            return 0;
        }
    }

    public void commitDie()
    {
        gm.cars.Remove(this);
        grid.grid[collTile].entities.Remove(gameObject);
        Destroy(gameObject);
    }

    private void Update()
    {
        //if (Input.GetKeyDown(KeyCode.Space))
        //{
        //    Step();
        //}
        transform.rotation = Quaternion.Lerp(transform.rotation, targetRotation, 0.125f);
        if (gm) stepProgress = gm.stepProgress;
        transform.position = Vector3.Lerp(oldPosition, truePosition, stepProgress);
    }
}
