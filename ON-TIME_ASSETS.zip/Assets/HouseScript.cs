using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class HouseScript : MonoBehaviour
{
    public int X = 0;
    public int Y = 0;

    public GridScript grid;

    public GameManager gm;
    public TMP_Text text;

    public bool served = false;
    public int time = 10;

    public int index = 0;
    private bool updatedGraphics = false;

    public Sprite servedSprite;

    public ParticleSystem particle;

    private void Awake()
    {
        text.text = time.ToString();
        transform.position = grid.getTileCoordinate(X, Y);
        index = grid.getTileIndex(X, Y);
        grid.grid[index].entities.Add(gameObject);
    }

    private void Relocate()
    {
        grid.grid[index].entities.Remove(gameObject);
        text.text = time.ToString();
        transform.position = grid.getTileCoordinate(X, Y);
        index = grid.getTileIndex(X, Y);
        grid.grid[index].entities.Add(gameObject);
    }

    public void Step()
    {
        if (!served)
        {
            time--;
            text.text = time.ToString();
            if (time <= 0) gm.EndGame(false);
        } else if (!updatedGraphics)
        {
            text.gameObject.SetActive(false);
            GetComponent<SpriteRenderer>().sprite = servedSprite;
            particle.Emit(1);
            updatedGraphics = true;
        }
    }
}
