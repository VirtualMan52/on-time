using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class LevelSelectScript : MonoBehaviour
{
    public bool timerRunning = false;
    public float transitionTime = 1f;
    public string nextScene;

    public Animator transition;
    public AudioSource music;

    public void Click(string s)
    {
        if (!timerRunning)
        {
            nextScene = s;
            timerRunning = true;
            transition.SetBool("Close", true);
        }
    }

    void Update()
    {
        if (timerRunning)
        {
            music.volume = 0.3f * (transitionTime / 1f);
            transitionTime -= Time.deltaTime;
            if (transitionTime <= 0)
            {
                SceneManager.LoadScene(nextScene);
            }
        }
    }
}
