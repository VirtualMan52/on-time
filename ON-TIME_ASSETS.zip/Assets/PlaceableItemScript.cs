using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlaceableItemScript : MonoBehaviour
{
    public int X = 0;
    public int Y = 0;

    public GridScript grid;
    public Vector3 truePosition;

    public GameManager gm;

    private void Start()
    {
        Relocate();
    }

    private void Relocate()
    {
        truePosition = grid.getTileCoordinate(X, Y); ;
    }

    private void Update()
    {
        transform.position = truePosition + new Vector3(0f,Mathf.Sin(Time.time) / 10f,0f);
    }
}
