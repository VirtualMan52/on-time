using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class UIManager : MonoBehaviour
{
    public float slotWidth = 150f;
    public GameObject slotTemplate;

    public List<PlaceableItem> items;

    public List<GameObject> slots;
    public GameManager gm;

    public Color selectedColor;
    public Color normalColor;

    public void ButtonClick(Button b)
    {
        int self = slots.IndexOf(b.gameObject);
        if (gm.selectingItem && gm.selectedItem == self)
        {
            gm.selectingItem = false;
        } else
        {
            gm.selectingItem = true;
            gm.selectedItem = self;
        }
        gm.selectSound.Play();
        UpdateButtonColors();
    }

    public void UpdateButtonColors()
    {
        int j = 0;
        foreach (GameObject o in slots)
        {
            Image b = o.GetComponent<Image>();
            b.color = gm.selectedItem == j && gm.selectingItem ? selectedColor : normalColor;
            j++;
        };
    }

    public void UpdateButtons()
    {
        for (int i=0; i<slots.Count; i++)
        {
            slots[i].transform.Find("Text").GetComponent<TMP_Text>().text = items[i].curAmount.ToString();
        };
    }

    public void RenderSlots()
    {
        foreach (GameObject o in slots)
        {
            Destroy(o);
        };
        slots.Clear();

        int j = 0;
        foreach (PlaceableItem i in items)
        {
            GameObject s = Instantiate(slotTemplate);
            s.transform.Find("Image").GetComponent<Image>().sprite = i.spr;
            s.transform.Find("Text").GetComponent<TMP_Text>().text = i.curAmount.ToString();

            s.GetComponent<RectTransform>().SetParent(transform.parent,false);
            s.GetComponent<RectTransform>().anchoredPosition = new Vector2(-((items.Count - 1) * 0.5f * slotWidth) + (slotWidth * j), 50f);
            s.SetActive(true);

            slots.Add(s);
            j++;
        };
        gameObject.GetComponent<RectTransform>().SetSizeWithCurrentAnchors(RectTransform.Axis.Horizontal, slotWidth * items.Count);
    }

    public void Play()
    {
        gm.Play();
    }
}
