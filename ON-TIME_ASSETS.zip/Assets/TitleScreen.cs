using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class TitleScreen : MonoBehaviour
{
    public float speed;
    public GameObject grid;
    public GameObject houseTemplate1;
    public GameObject houseTemplate2;
    public GameObject pizzaTemplate;
    public List<GameObject> move;

    public bool timerRunning = false;
    public float transitionTime = 1f;
    public string nextScene;

    public Animator transition;

    public AudioSource music;

    public void Click()
    {
        if (!timerRunning)
        {
            timerRunning = true;
            transition.SetBool("Close", true);
        }
    }

    public void QuitApp()
    {
        Application.Quit();
    }

    void Update()
    {
        grid.transform.position -= new Vector3(Time.deltaTime * speed,0f,0f);

        foreach (GameObject o in move)
        {
            o.transform.position -= new Vector3(Time.deltaTime * speed, 0f, 0f);
        }

        List<GameObject> moved = move;
        foreach (GameObject o in moved)
        {
            if (o.transform.position.x < -6.5f)
            {
                move.Remove(o);
                Destroy(o);
            }
        }

        if (grid.transform.position.x < -1.5f)
        {
            grid.transform.position += new Vector3(1f, 0f, 0f);
            float r = Random.Range(0f,100f);
            if (r <= 5f)
            {
                GameObject o = Instantiate(pizzaTemplate);
                o.SetActive(true);
                move.Add(o);
            } else if (r <= 35f)
            {
                GameObject o = Instantiate(houseTemplate1);
                o.SetActive(true);
                move.Add(o);
            } else if (r <= 65f) {
                GameObject o = Instantiate(houseTemplate2);
                o.SetActive(true);
                move.Add(o);
            }
        }

        if (timerRunning)
        {
            music.volume = 0.3f * (transitionTime / 1f);
            transitionTime -= Time.deltaTime;
            if (transitionTime <= 0)
            {
                SceneManager.LoadScene(nextScene);
            }
        }
    }
}
