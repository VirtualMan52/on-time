using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ScooterScript : MonoBehaviour
{
    public int startX = 0;
    public int startY = 0;

    public int X = 0;
    public int Y = 0;

    public int dirX = 1;
    public int dirY = 0;

    public GridScript grid;

    public Quaternion targetRotation;
    public Vector3 oldPosition;
    public Vector3 truePosition;
    public float stepProgress = 1f;

    public GameManager gm;

    public AudioSource rotateSound;
    public AudioSource deliver;
    public List<AudioClip> deliverClips;
    public int clip = 0;

    public List<GameObject> collisionObjects;
    public int lastTile;
    public int collTile;

    private void Awake()
    {
        X = startX;
        Y = startY;
        //grid = transform.root.Find("Grid").GetComponent<GridScript>();
        truePosition = grid.getTileCoordinate(startX, startY);
        oldPosition = truePosition;
        FaceDir();
        transform.rotation = targetRotation;
        transform.position = truePosition;
    }

    public void FaceDir()
    {
        if (dirX == 1) { targetRotation = Quaternion.Euler(0, 0, 270); }
        else if (dirX == -1) { targetRotation = Quaternion.Euler(0, 0, 90); }
        else if (dirY == -1) { targetRotation = Quaternion.Euler(0, 0, 0); }
        else { targetRotation = Quaternion.Euler(0, 0, 180); }
    }

    public void TurnRight()
    {
        if (dirX == -1) { dirX = 0; dirY = -1; }
        else if (dirX == 1) { dirX = 0; dirY = 1; }
        else if (dirY == -1) { dirX = 1; dirY = 0; }
        else { dirX = -1; dirY = 0; }
    }

    public void TurnLeft()
    {
        if (dirX == 1) { dirX = 0; dirY = -1; }
        else if (dirX == -1) { dirX = 0; dirY = 1; }
        else if (dirY == 1) { dirX = 1; dirY = 0; }
        else { dirX = -1; dirY = 0; }
    }

    public void Step()
    {
        oldPosition = transform.position;

        //IF ON ROTATE ENTITY, ROTATE 
        //ELSE IF ON ROAD AND BLOCK FORWARD, 
        int curTile = grid.getTileIndex(X, Y);
        lastTile = curTile;
        string n = grid.placeableItem(curTile);
        if (grid.containsPlaceableItem(curTile))
        {
            if (n == "RightTurn" || n == "PoliceRightTurn") {
                TurnRight();
                rotateSound.pitch = Random.Range(0.8f, 1.2f);
                rotateSound.Play();
                if (n == "PoliceRightTurn") grid.playWhistle(curTile);
            } else
            {
                TurnLeft();
                rotateSound.pitch = Random.Range(0.8f,1.2f);
                rotateSound.Play();
                if (n == "PoliceLeftTurn") grid.playWhistle(curTile);
            }
        } else if (grid.getTileAt(X + dirX, Y + dirY) == 0)
        {
            TurnLeft();
            if (!(grid.getTileAt(X + dirX, Y + dirY) != 0 && grid.getTileAt(X - dirX, Y - dirY) == 0))
            {
                TurnRight();
                TurnRight();
            }
        }

        //ELSE GO FORTH

        if (grid.getTileAt(X + dirX, Y + dirY) != 0)
        {
            X += dirX;
            Y += dirY;
        }

        collTile = grid.getTileIndex(X, Y);
        collisionObjects = grid.vehicle(collTile);

        if (grid.grid[lastTile].entities.Contains(gameObject)) grid.grid[lastTile].entities.Remove(gameObject);
        grid.grid[collTile].entities.Add(gameObject);

        bool houseServed = false;
        HouseScript h = grid.House(grid.getTileIndex(X, Y + 1));
        if (h != null) { if (h.served == false) houseServed = true;  h.served = true; }
        h = grid.House(grid.getTileIndex(X, Y - 1));
        if (h != null) { if (h.served == false) houseServed = true; h.served = true; }
        h = grid.House(grid.getTileIndex(X + 1, Y));
        if (h != null) { if (h.served == false) houseServed = true; h.served = true; }
        h = grid.House(grid.getTileIndex(X - 1, Y));
        if (h != null) { if (h.served == false) houseServed = true; h.served = true; }

        if (houseServed)
        {
            deliver.clip = deliverClips[clip];
            clip++;
            if (clip >= deliverClips.Count) clip = 0;
            if (!gm.winMusic.isPlaying) deliver.Play();
        }

        FaceDir();
        truePosition = grid.getTileCoordinate(X, Y);
    }

    public void CollisionStep()
    {
        bool endGame = false;
        foreach (GameObject o in collisionObjects)
        {
            Debug.Log(o.name);
            if (o != gameObject && (grid.vehicle(collTile).Contains(o) || grid.vehicle(lastTile).Contains(o)))
            {
                endGame = true;
            }
        }
        if (endGame)
        {
            gm.EndGame(true);
        }
    }

    private void Update()
    {
        //if (Input.GetKeyDown(KeyCode.Space))
        //{
        //    Step();
        //}
        transform.rotation = Quaternion.Lerp(transform.rotation, targetRotation, 0.125f);
        if (gm) stepProgress = gm.stepProgress;
        transform.position = Vector3.Lerp(oldPosition, truePosition, stepProgress);
    }
}
