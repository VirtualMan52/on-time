using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class CutsceneManager : MonoBehaviour
{
    public bool timerRunning = false;
    public float transitionTime = 1f;
    public string nextScene;

    public Animator transition;

    public void Click()
    {
        if (!timerRunning)
        {
            timerRunning = true;
            transition.SetBool("Close", true);
        }
    }

    void Update()
    {
        if (timerRunning)
        {
            transitionTime -= Time.deltaTime;
            if (transitionTime <= 0)
            {
                SceneManager.LoadScene(nextScene);
            }
        }
    }
}
