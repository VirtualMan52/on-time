using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GridScript : MonoBehaviour
{
    public bool levelEditing = false;

    [System.Serializable]
    public class GridTile
    {
        public int gridX;
        public int gridY;

        public int tileType = 0;
        public List<GameObject> entities = new List<GameObject>();
    }

    public List<Sprite> possibleTiles;
    //0: Grass
    //1: Road
    //2: TurnRight
    //3: TurnLeft

    [SerializeField] public List<GridTile> grid = new List<GridTile>();
    private List<GameObject> gridObjects = new List<GameObject>();
    public int gridX;
    public int gridY;

    public float tileSize = 1f;

    [SerializeField] private GameObject tilePrefab;
    [SerializeField] private GameObject Outline;

    private void Start()
    {
        RenderGrid();
    }

    private void RenderGrid()
    {
        //Debug.Log("grid rendered");
        foreach (GameObject o in gridObjects)
        {
            Destroy(o);
        };
        gridObjects.Clear();
    
        for (int y = 0; y < gridY; y++)
        {
            for (int x = 0; x < gridX; x++)
            {
                GridTile cur;
                if (grid.Count < gridX * gridY || grid[(y*gridX)+x] == null)
                {
                    GridTile newTile = new GridTile();
                    newTile.gridX = x;
                    newTile.gridY = y;
                    grid.Add(newTile);
                    cur = newTile;
                } else
                {
                    cur = grid[(y * gridX) + x];
                }

                GameObject t = Instantiate(tilePrefab);
                gridObjects.Add(t);
                t.transform.parent = transform;
                t.transform.position = new Vector3(cur.gridX*tileSize - (gridX*tileSize*0.5f) + tileSize/2, -(cur.gridY * tileSize) + (gridY * tileSize * 0.5f) - tileSize/2, 0f);
                t.GetComponent<SpriteRenderer>().sprite = possibleTiles[cur.tileType];
            }
        }

        Outline.transform.localScale = new Vector3(gridX*tileSize+0.1f, gridY * tileSize + 0.1f,0f);
    }

    public Vector2 getTileCoordinate(int x, int y)
    {
        GridTile cur = grid[(y * gridX) + x];
        return new Vector3(cur.gridX * tileSize - (gridX * tileSize * 0.5f) + tileSize / 2, -(cur.gridY * tileSize) + (gridY * tileSize * 0.5f) - tileSize / 2, 0f);
    }

    public int getTileAt(int x, int y)
    {
        GridTile cur = grid[(y * gridX) + x];
        return cur.tileType;
    }

    public int getTileIndex(int x, int y)
    {
        return (y * gridX) + x;
    }

    public int getTileIndexRaw(float x, float y)
    {
        int tileX = (int)((x + (gridX * tileSize * 0.5f)) / tileSize);
        int tileY = (int)((-y + (gridY * tileSize * 0.5f)) / tileSize);
        return (tileY * gridX) + tileX;
    }

    public Vector2 getTileCoordinatesRaw(float x, float y)
    {
        int tileX = (int)((x + (gridX * tileSize * 0.5f)) / tileSize);
        int tileY = (int)((-y + (gridY * tileSize * 0.5f)) / tileSize);
        return new Vector2(tileX,tileY);
    }

    public bool containsPlaceableItem(int index)
    {
        bool f = false;
        foreach (GameObject e in grid[index].entities)
        {
            if (e.GetComponent<PlaceableItemScript>() != null) f = true;
        }
        return f;
    }

    public bool containsPlaceableItemCar(int index)
    {
        bool f = false;
        foreach (GameObject e in grid[index].entities)
        {
            if (e.GetComponent<PlaceableItemScript>() != null && (e.name.Replace("(Clone)", "") == "PoliceRightTurn" || e.name.Replace("(Clone)", "") == "PoliceLeftTurn")) f = true;
        }
        return f;
    }

    public string placeableItem(int index)
    {
        GameObject s = null;
        foreach (GameObject e in grid[index].entities)
        {
            if (e.GetComponent<PlaceableItemScript>() != null) s = e;
        }
        if (s == null) return "None";
        string n = s.name.Replace("(Clone)", "");
        return n;
    }

    public void playWhistle(int index)
    {
        GameObject s = null;
        foreach (GameObject e in grid[index].entities)
        {
            if (e.GetComponent<PlaceableItemScript>() != null) s = e;
        }
        if (s == null) return;
        else if (s.name.Replace("(Clone)", "") == "PoliceRightTurn" || s.name.Replace("(Clone)", "") == "PoliceLeftTurn")
        {
            s.GetComponent<AudioSource>().pitch = Random.Range(0.8f, 1.2f);
            s.GetComponent<AudioSource>().Play();
            s.GetComponent<Animator>().Play("Whistle");
        }
        return;
    }

    public List<GameObject> vehicle(int index)
    {
        List<GameObject> s = new List<GameObject>();
        foreach (GameObject e in grid[index].entities)
        {
            if (e.GetComponent<ScooterScript>() != null || e.GetComponent<CarScript>() != null) s.Add(e);
        }
        return s;
    }

    public HouseScript House(int index)
    {
        GameObject s = null;
        foreach (GameObject e in grid[index].entities)
        {
            if (e.GetComponent<HouseScript>() != null) s = e;
        }
        if (s == null) { return null; } else { return s.GetComponent<HouseScript>(); }
    }

    public string removePlaceableItem(int index)
    {
        GameObject s = null;
        foreach (GameObject e in grid[index].entities)
        {
            if (e.GetComponent<PlaceableItemScript>() != null) s = e;
        }
        if (s == null) return "None";
        grid[index].entities.Remove(s);
        string n = s.name.Replace("(Clone)","");
        Destroy(s);
        return n;
    }

    public void Update()
    {
        if (Input.GetMouseButtonDown(0) && levelEditing)
        {
            Vector3 mousePos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
            grid[getTileIndexRaw(mousePos.x, mousePos.y)].tileType++;
            if (grid[getTileIndexRaw(mousePos.x, mousePos.y)].tileType > possibleTiles.Count - 1) grid[getTileIndexRaw(mousePos.x, mousePos.y)].tileType = 0;
            RenderGrid();
        }
    }
}
