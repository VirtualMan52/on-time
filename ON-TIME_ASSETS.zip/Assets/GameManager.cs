using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using TMPro;

[System.Serializable]
public class PlaceableItem
{
    public int startAmount;
    public string name;
    public Sprite spr;
    public int curAmount;
    public GameObject prefab;
}

public class GameManager : MonoBehaviour
{
    public string gameState = "Placing";

    public float stepLength = 1f;
    public float stepTime = 0f;
    public float stepProgress;

    public GridScript grid;
    public UIManager ui;
    public GameObject gameOverScreen;
    public GameObject winScreen;
    public List<HouseScript> houses;
    public List<CarScript> cars;
    public List<ScooterScript> scooters;

    public bool selectingItem = false;
    public int selectedItem = 0;
    public List<PlaceableItem> items;

    public GameObject tutorial;
    public float TransitionTimer = 0f;
    public float TransitionTime = 1f;
    public Animator Transition;

    public string nextLevel = "SampleScene";

    public float musicVolume = 1f;
    public AudioSource placementMusic;
    public AudioSource rollingMusic;
    public AudioSource winMusic;
    public AudioSource loseMusic;

    public AudioSource selectSound;
    public AudioSource placeSound;
    public AudioSource removeSound;

    private void Awake()
    {
        ui.gm = this;
        foreach (CarScript car in cars)
        {
            car.gm = this;
        }
        foreach (HouseScript house in houses)
        {
            house.gm = this;
        }
        foreach (ScooterScript scooter in scooters)
        {
            scooter.gm = this;
        }

        foreach (PlaceableItem i in items)
        {
            i.curAmount = i.startAmount;
        }
        ui.items = items;
        ui.RenderSlots();
        placementMusic.Play();
    }

    private void Update()
    {
        if (gameState == "Placing")
        {
            if (!placementMusic.isPlaying) placementMusic.Play();
            if (Input.GetMouseButtonDown(0))
            {
                Vector3 mousePos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
                if (mousePos.x < grid.tileSize * grid.gridX * 0.5f && mousePos.x > grid.tileSize * grid.gridX * -0.5f && mousePos.y < grid.tileSize * grid.gridY * 0.5f && mousePos.y > grid.tileSize * grid.gridY * -0.5f)
                {
                    Vector2 mouseCell = grid.getTileCoordinatesRaw(mousePos.x, mousePos.y);
                    int mouseIndex = grid.getTileIndexRaw(mousePos.x, mousePos.y);
                    if (grid.containsPlaceableItem(mouseIndex))
                    {
                        string n = grid.removePlaceableItem(mouseIndex);
                        removeSound.Play();
                        foreach (PlaceableItem i in items)
                        {
                            if (i.name == n)
                            {
                                i.curAmount++;
                                ui.UpdateButtons();
                                return;
                            }
                        }
                    }
                    else if (selectingItem && items[selectedItem].curAmount > 0)
                    {
                        GameObject o = Instantiate(items[selectedItem].prefab);
                        o.transform.parent = transform.parent;
                        o.GetComponent<PlaceableItemScript>().X = (int)mouseCell.x;
                        o.GetComponent<PlaceableItemScript>().Y = (int)mouseCell.y;
                        o.GetComponent<PlaceableItemScript>().gm = this;
                        o.GetComponent<PlaceableItemScript>().grid = grid;
                        o.transform.position = grid.getTileCoordinate((int)mouseCell.x,(int)mouseCell.y);
                        o.SetActive(true);

                        grid.grid[mouseIndex].entities.Add(o);

                        items[selectedItem].curAmount--;
                        ui.items = items;
                        ui.UpdateButtons();
                        placeSound.Play();
                    }
                }
            }
        } else if (gameState == "Rolling")
        {
            if (placementMusic.isPlaying) placementMusic.Stop();
            if (!rollingMusic.isPlaying) rollingMusic.Play();
            stepTime += Time.deltaTime;
            if (stepTime >= stepLength)
            {
                stepTime -= stepLength;
                stepProgress = stepTime / stepLength;
                Step();
            } else
            {
                stepProgress = stepTime / stepLength;
            }
        } else if (gameState == "Crash")
        {
            stepTime += Time.deltaTime;
            if (stepTime >= stepLength / 2)
            {
                stepTime = stepLength / 2;
                stepProgress = 0.5f;
                gameState = "Restart";
            }
            else
            {
                stepProgress = stepTime / stepLength;
            }
        } else if (gameState == "Win")
        {
            if (rollingMusic.isPlaying) rollingMusic.Stop();
        } else if (gameState == "Restarting" || gameState == "SwitchingLevels" || gameState == "LoadingLevelSelect")
        {
            TransitionTimer += Time.deltaTime;
            musicVolume = 1 - (TransitionTimer / TransitionTime);
            if (TransitionTimer >= TransitionTime)
            {
                if (gameState == "Restarting") SceneManager.LoadScene(SceneManager.GetActiveScene().name);
                else if (gameState == "SwitchingLevels") SceneManager.LoadScene(nextLevel);
                else if (gameState == "LoadingLevelSelect") SceneManager.LoadScene("LevelSelect");
            }
        }

        placementMusic.volume = 0.3f * (musicVolume / 1f);
        rollingMusic.volume = 0.3f * (musicVolume / 1f);
        winMusic.volume = 0.3f * (musicVolume / 1f);
        loseMusic.volume = 0.3f * (musicVolume / 1f);
    }

    private void Step()
    {
        int unservedHouses = houses.Count;
        foreach (HouseScript house in houses)
        {
            house.Step();
            if (house.served) unservedHouses--;
        }
        if (unservedHouses <= 0 && houses.Count > 0)
        {
            gameState = "Win";
            winScreen.SetActive(true);
            foreach (ScooterScript scooter in scooters)
            {
                if (scooter.deliver.isPlaying) scooter.deliver.Stop();
            }
            if (rollingMusic.isPlaying) rollingMusic.Stop();
            winMusic.Play();
        }
        foreach (CarScript car in cars)
        {
            car.Step();
        }
        foreach (ScooterScript scooter in scooters)
        {
            scooter.Step();
        }
        for (int i = 0; i<cars.Count; i++)
        {
            CarScript car = cars[i];
            int d = car.CollisionStep();
            i -= d;
            if (i < 0) i = 0;
        }
        foreach (ScooterScript scooter in scooters)
        {
            scooter.CollisionStep();
        }
    }

    public void Play()
    {
        if (gameState == "Placing") { gameState = "Rolling"; ui.transform.parent.gameObject.SetActive(false); }
    }

    public void Restart()
    {
        if (gameState == "Restart") { gameState = "Restarting"; Transition.SetBool("Close", true); }
    }

    public void NextLevel()
    {
        if (gameState == "Win") { gameState = "SwitchingLevels"; Transition.SetBool("Close", true); }
    }

    public void LevelSelect()
    {
        if (gameState == "Win" || gameState == "Restart") { gameState = "LoadingLevelSelect"; Transition.SetBool("Close", true); }
    }

    public void EndGame(bool halfstep)
    {
        gameState = halfstep ? "Crash" : "Restart";
        if (halfstep) gameOverScreen.transform.Find("Text").GetComponent<TMP_Text>().text = "OUCH!";
        gameOverScreen.SetActive(true);
        if (rollingMusic.isPlaying) rollingMusic.Stop();
        loseMusic.Play();
    }

    public void CloseTutorial()
    {
        Destroy(tutorial);
        placeSound.Play();
    }
}
